=======
Credits
=======

Development Lead
================

* Nick Stenning <nick@whiteink.com>

Contributors
============

* Jannis Leidel <jannis@leidel.info>
* Marc Abramowitz (@msabramo) <marc@marc-abramowitz.com> - maintainer
* Sławomir Ehlert (@slafs) <slafs.e@gmail.com> - maintainer
* Jiangge Zhang
* Thomas Orozco
* Alex Morega
* Igor Davydenko
* Alen Mujezinovic
* Jean-Philippe Serafin
* Alejandro Varas
* Hannes Struss
* Jeethu Rao
* Jökull Sólberg Auðunsson
* Andrii Kurinnyi
* Chad Whitacre
* Hyunjun Kim
* Jesse Pollak
* Mark Burnett
* Miguel Grinberg
* Pepijn de Vos
* Philippe Ombredanne
