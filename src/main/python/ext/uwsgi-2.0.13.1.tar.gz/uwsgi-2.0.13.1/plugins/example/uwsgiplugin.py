NAME='example'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['example_plugin']
