NAME='syslog'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['syslog_plugin']
