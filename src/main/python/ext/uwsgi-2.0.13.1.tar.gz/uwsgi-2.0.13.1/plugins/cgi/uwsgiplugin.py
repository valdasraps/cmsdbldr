NAME='cgi'
CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['cgi_plugin']
